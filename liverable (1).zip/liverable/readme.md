# 1. Introduction

Ce project a pour but de developer une application web en JavaScript. L'application est composee de deux system: un system backend - qui
contient la logique de l'application et un system frontend - qui represent l'interface avec laquelle l'utilisateur interagit avec le system. Les deux systems communiquent par le biais du protocole REST.

# 2. Context

L'application represent un simple e-commerce site web

# 3. Cahier des charges

-   Creation d'un compte admin
-   Creation d'un produit avec un nom, description, prix et image
-   Modification et suppression d'un produit
-   Un utilisateur normal peut acheter un produit

# 4. Description detaillee de la solution

La solution permet de creer un compte admin qui permet de manager le `store` en creeant des articles (produits), il a la possibilite de modifier ou supprimer un produit. Un utilisateur (ou admin) peut naviguer sur le `store` et peux acheter des produits. Un recapitulatif de l'achat est affiche a l'utilisateur qui peut modifier la commande puis la confirmer.

# 5. Limites de la solution

-   Si la page est rafraichie les produits selectiones par l'utilisateur seront perdus.
-   Ce n'est pas possible de creer plusieur comptes.
-   Il n'y a pas de possibilite de laisser des avis sur produit

# 6. Conclusion et axes d'amelioration:

-   On peut utiliser `localStorage` pour sauvegarder la session
-   La solution peut etre ameliorer pour qu'un utilisateur puisse avoir un compte avec un historique, statistique sur les achats etc...
-   Ajouter la possibilited de laisser des avis et note un produit.

# Run App:

Prerequisite:

-   NodeJS: https://nodejs.org/en/download
-   NPM: https://docs.npmjs.com/downloading-and-installing-node-js-and-npm

Backend:

-   cd to ./server
-   run `npm install`
-   run `npm run dev`
-   wait until `[server]: running on port 3001` is displayed

Frontend:

-   cd to ./web
-   run `npm install`
-   run `npm run dev`
-   the app should be accessible from `localhost:3000`
