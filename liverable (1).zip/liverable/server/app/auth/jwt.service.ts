import jwt, { JwtPayload } from "jsonwebtoken";
import { AuthPayload } from "./auth.route";

let instance: JWTService = null;

export interface JWTConfig {
    secret: string;
    expiresIn: string;
}

export class JWTService {
    private constructor(private readonly config: JWTConfig) {}

    sign(payload: AuthPayload): string {
        return jwt.sign(payload, this.config.secret, {
            expiresIn: this.config.expiresIn,
        });
    }

    verify(token: string): AuthPayload {
        try {
            // @ts-ignore
            const result: jwt.JwtPayload = jwt.verify(
                token,
                this.config.secret
            );
            return AuthPayload.fromVerifyResult(result);
        } catch {
            return null;
        }
    }

    static getInstance(config: JWTConfig): JWTService {
        if (instance === null) {
            instance = new JWTService(config);
        }
        return instance;
    }
}
