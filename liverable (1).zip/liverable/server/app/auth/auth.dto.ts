export interface SignInDTO {
    username: string;
    password: string;
}

export interface SignInResponseDTO {
    token: string;
}
