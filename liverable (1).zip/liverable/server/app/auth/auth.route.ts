import jwt, { JwtPayload } from "jsonwebtoken";
import bcrypt from "bcrypt";
import { Request, Response, incorrectCredentialsError } from "@/app/common";
import { JWTConfig, JWTService } from "./jwt.service";
import { UserService } from "../user/user.service";
import { SignInDTO, SignInResponseDTO } from "./auth.dto";
import { User } from "../user/user.entity";
import { DataSource } from "typeorm";
import { Route, createRoute } from "@/app/route";
import { httpPOST } from "@/constants";

const basePath: string = "auth";

export class AuthPayload {
    username: string;

    static fromVerifyResult(payload: jwt.JwtPayload) {
        return {
            username: payload.username,
        };
    }
}

export class AuthController {
    constructor(
        private readonly jwtService: JWTService,
        private readonly userService: UserService
    ) {
        this.signin = this.signin.bind(this);
    }

    async signin(req: Request<SignInDTO>, res: Response) {
        const dto: SignInDTO = req.body;

        const user: User = await this.userService.getByUsername(dto.username);
        if (user === null || !bcrypt.compareSync(dto.password, user.password)) {
            res.errors.push(incorrectCredentialsError);
        } else {
            res.data = {
                token: this.jwtService.sign({
                    username: user.username,
                } as AuthPayload),
            } as SignInResponseDTO;
        }
    }
}

export const createAuthRoutes = (
    config: JWTConfig,
    datasource: DataSource
): Route[] => {
    const authController: AuthController = new AuthController(
        JWTService.getInstance(config),
        UserService.getInstance(datasource.getRepository(User))
    );

    return [createRoute(httpPOST, `${basePath}/signin`, authController.signin)];
};
