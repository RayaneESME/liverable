import { Request, Response, unauthorizedActionError } from "@/app/common";
import { JWTConfig, JWTService } from "./jwt.service";
import { IncomingHttpHeaders } from "http";
import { Middleware, createMiddleware } from "../middleware";
import { AuthPayload } from "./auth.route";
import { DataSource } from "typeorm";
import { UserService } from "../user/user.service";
import { User } from "../user/user.entity";

export const createAuthMiddleware = (
    config: JWTConfig,
    datasource: DataSource
): Middleware => {
    const jwtService: JWTService = JWTService.getInstance(config);
    const userService: UserService = UserService.getInstance(
        datasource.getRepository(User)
    );

    return createMiddleware(async (req: Request, res: Response) => {
        const token: string | null = extractJWTToken(req.headers);
        const payload: AuthPayload = jwtService.verify(token);

        if (token === null || payload === null) {
            res.errors.push(unauthorizedActionError);
            return;
        }

        req.currentUser = await userService.getByUsername(payload.username);
    });
};

const extractJWTToken = (headers: IncomingHttpHeaders): string | null => {
    const [type, token] = headers.authorization?.split(" ") ?? [];
    return type === "Bearer" ? token : null;
};
