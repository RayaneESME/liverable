import fs from "fs";
import url, { UrlWithStringQuery } from "url";
import { imagesDir, staticDir } from "@/constants";
import { join } from "path";
import { AppConfig } from "../config";

let instance: FileSystemService = null;

const imageURLBasePath: string = "static/images";

export class FileSystemService {
    constructor(private readonly config: AppConfig) {}

    saveImage(b64Image: string, imageDir: string, name: string): string {
        const imageFilename: string = generateRandomName(name);
        const imageURL: string = `http://${this.config.domain}:${this.config.port}/${imageURLBasePath}/${imageDir}/${imageFilename}`;
        fs.writeFileSync(
            join(imagesDir, imageDir, imageFilename),
            Buffer.from(b64Image, "base64")
        );
        return imageURL;
    }

    updateImage(
        b64Image: string,
        imageDir: string,
        name: string,
        imageURL: string
    ) {
        this.deleteImage(imageDir, imageURL);
        return this.saveImage(b64Image, imageDir, name);
    }

    deleteImage(imageDir: string, imageURL: string) {
        const splitted: string[] = url.parse(imageURL).pathname.split("/");
        const imageFilename: string = splitted[splitted.length - 1];
        try {
            fs.rmSync(join(imagesDir, imageDir, imageFilename));
        } catch {}
    }

    static getInstance(config: AppConfig) {
        if (instance === null) {
            instance = new FileSystemService(config);
        }
        return instance;
    }
}

const generateRandomName = (prefix: string): string => {
    return `${prefix}_${(Math.random() + 1).toString(36).substring(7)}`;
};
