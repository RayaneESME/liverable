import {
    Column,
    CreateDateColumn,
    Entity,
    ManyToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from "typeorm";
import { User } from "../user/user.entity";

@Entity()
export class Product {
    @PrimaryGeneratedColumn("uuid")
    id: string;

    @Column({ unique: true })
    name: string;

    @Column()
    description: string;

    @Column("decimal")
    price: number;

    @Column()
    imageURL: string;

    @ManyToOne(() => User, (user) => user.products)
    createBy: User;

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn()
    updatedAt: Date;

    constructor(
        name: string,
        description: string,
        price: number,
        imageURL: string
    ) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageURL = imageURL;
    }
}
