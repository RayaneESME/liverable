import {
    IsNumberString,
    IsString,
    IsUrl,
    Length,
    MaxLength,
} from "class-validator";
import { Product } from "./product.entity";
import {
    productDescriptionMaxLength,
    productNameMaxLength,
    productNameMinLength,
} from "../validation/constraints";

export class ProductCreationDTO {
    @IsString()
    @Length(productNameMinLength, productNameMaxLength)
    name: string;

    @IsString()
    @MaxLength(productDescriptionMaxLength)
    description: string;

    @IsNumberString()
    price: string;

    b64Image: string;
    imageURL?: string;

    static toProduct(dto: ProductCreationDTO): Product {
        return new Product(
            dto.name,
            dto.description,
            parseFloat(dto.price),
            dto.imageURL
        );
    }
}

export class ProductUpdateDTO {
    @IsString()
    @Length(productNameMinLength, productNameMaxLength)
    name: string;

    @IsString()
    @MaxLength(productDescriptionMaxLength)
    description: string;

    @IsNumberString()
    price: string;

    imageURL: string;

    b64Image: string;

    constructor(name: string, description: string, imageURL: string) {
        this.name = name;
        this.description = description;
        this.imageURL = imageURL;
    }

    static toProduct(dto: ProductUpdateDTO): Product {
        return new Product(
            dto.name,
            dto.description,
            parseFloat(dto.price),
            dto.imageURL
        );
    }
}

export class ProductQueryDTO {
    id: string;
    name: string;
    description: string;
    price: number;
    imageURL: string;

    static fromProduct(product: Product): ProductQueryDTO {
        return {
            id: product.id,
            name: product.name,
            description: product.description,
            price: product.price,
            imageURL: product.imageURL,
        };
    }
}
