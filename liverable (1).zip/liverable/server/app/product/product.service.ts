import { Repository } from "typeorm";
import { Product } from "./product.entity";

let instance: ProductService = null;

export class ProductService {
    private constructor(private readonly productRepo: Repository<Product>) {}

    async create(produt: Product): Promise<Product> {
        return await this.productRepo.save(produt);
    }

    async getByID(productID: string): Promise<Product> {
        return await this.productRepo.findOne({ where: { id: productID } });
    }

    async getAll(): Promise<Product[]> {
        return await this.productRepo.find();
    }

    async update(productID: string, product: Product): Promise<Product> {
        await this.productRepo.update({ id: productID }, product);
        return product;
    }

    async delete(productID: string): Promise<void> {
        await this.productRepo.delete({ id: productID });
    }

    static getInstance(productRepo: Repository<Product>): ProductService {
        if (instance === null) {
            instance = new ProductService(productRepo);
        }
        return instance;
    }
}
