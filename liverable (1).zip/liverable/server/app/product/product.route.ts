import {
    ProductCreationDTO,
    ProductQueryDTO,
    ProductUpdateDTO,
} from "./product.dto";
import { Request, Response } from "@/app/common";
import { ProductService } from "./product.service";
import { Product } from "./product.entity";
import { Route, createRoute } from "../route";
import { DataSource } from "typeorm";
import { httpDELETE, httpGET, httpPOST, httpPUT } from "@/constants";
import { FileSystemService } from "../filesystem/filesystem.service";
import { AppConfig } from "../config";

const basePath: string = "product";

export class ProductController {
    constructor(
        private readonly productService: ProductService,
        private readonly filesystemService: FileSystemService
    ) {
        this.create = this.create.bind(this);
        this.update = this.update.bind(this);
        this.getAll = this.getAll.bind(this);
        this.delete = this.delete.bind(this);
    }

    async create(req: Request<ProductCreationDTO>, res: Response) {
        const dto: ProductCreationDTO = req.body;
        if (dto.b64Image) {
            dto.imageURL = this.filesystemService.saveImage(
                dto.b64Image,
                "products",
                dto.name
            );
        } else {
            dto.imageURL = "";
        }

        const productToCreate: Product = ProductCreationDTO.toProduct(dto);
        productToCreate.createBy = req.currentUser;

        const product: Product = await this.productService.create(
            productToCreate
        );
        res.data = ProductQueryDTO.fromProduct(product);
    }

    async update(req: Request<ProductUpdateDTO>, res: Response) {
        const dto: ProductUpdateDTO = req.body;
        if (dto.b64Image) {
            dto.imageURL = this.filesystemService.updateImage(
                req.body.b64Image,
                "products",
                dto.name,
                dto.imageURL
            );
        }
        const productID: string = req.params["id"];
        const product: Product = await this.productService.update(
            productID,
            ProductUpdateDTO.toProduct(dto)
        );

        res.data = ProductQueryDTO.fromProduct(product);
    }

    async getAll(_: Request, res: Response) {
        const products: Product[] = await this.productService.getAll();
        res.data = products.map((p: Product) => ProductQueryDTO.fromProduct(p));
    }

    async delete(req: Request, res: Response) {
        const product: Product = await this.productService.getByID(
            req.params["id"]
        );
        if (!product) return;

        await this.productService.delete(product.id);
        this.filesystemService.deleteImage("products", product.imageURL);
        res.data = product.imageURL;
    }
}

export const createProductRoutes = (
    config: AppConfig,
    datasource: DataSource
): Route[] => {
    const productController: ProductController = new ProductController(
        ProductService.getInstance(datasource.getRepository(Product)),
        FileSystemService.getInstance(config)
    );

    return [
        createRoute(httpPOST, basePath, productController.create, true),
        createRoute(httpPUT, `${basePath}/:id`, productController.update, true),
        createRoute(httpGET, basePath, productController.getAll),
        createRoute(
            httpDELETE,
            `${basePath}/:id`,
            productController.delete,
            true
        ),
    ];
};
