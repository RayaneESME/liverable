import { Repository } from "typeorm";
import { Setup } from "./setup.entity";
import { setupEntityID } from "@/constants";

let instance: SetupService = null;

export class SetupService {
    private constructor(private readonly setupRepo: Repository<Setup>) {}

    async setAdminCreated(): Promise<void> {
        let setup: Setup = await this.get();
        if (setup === null) {
            setup = new Setup(true);
        }
        await this.setupRepo.save(setup);
    }

    async get(): Promise<Setup> {
        const setup: Setup = await this.setupRepo.findOne({
            where: { id: setupEntityID },
        });
        return setup;
    }

    static getInstance(setupRepo: Repository<Setup>): SetupService {
        if (instance === null) {
            instance = new SetupService(setupRepo);
        }
        return instance;
    }
}
