import { SetupService } from "./setup.service";
import { Setup } from "./setup.entity";
import {
    Request,
    Response,
    adminFoundError,
    noAdminFoundError,
} from "@/app/common";
import { DataSource } from "typeorm";
import { createMiddleware } from "../middleware";
import { httpPOST, apiURLPrefix } from "@/constants";

export const createSetupMiddlewares = (datasource: DataSource) => {
    const setupService: SetupService = SetupService.getInstance(
        datasource.getRepository(Setup)
    );

    return [
        createMiddleware(async (req: Request, res: Response) => {
            const setup: Setup = await setupService.get();
            if (
                !isUserCreationReq(req) &&
                (setup === null || !setup.isAdminCreated)
            ) {
                res.errors.push(noAdminFoundError);
            }

            if (
                isUserCreationReq(req) &&
                setup !== null &&
                setup.isAdminCreated
            ) {
                res.errors.push(adminFoundError);
            }
        }),
    ];
};

const isUserCreationReq = (req: Request): boolean => {
    return req.url === `${apiURLPrefix}/user` && req.method === httpPOST;
};
