import { setupEntityID } from "@/constants";
import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryColumn,
    UpdateDateColumn,
} from "typeorm";

@Entity()
export class Setup {
    @PrimaryColumn({ default: setupEntityID })
    id: string;

    @Column()
    isAdminCreated: boolean;

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn()
    updatedAt: Date;

    constructor(isAdminCreated: boolean) {
        this.id = setupEntityID;
        this.isAdminCreated = isAdminCreated;
    }
}
