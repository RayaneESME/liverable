import { NextFunction, Router } from "express";
import { UserService } from "./user/user.service";
import { createUserRoutes } from "./user/user.route";
import { DataSource } from "typeorm";
import { Request, Response } from "./common";
import { createAuthRoutes } from "./auth/auth.route";
import { AppConfig } from "./config";
import { createProductRoutes } from "./product/product.route";

export interface Routes {
    public: Route[];
    protected: Route[];
}

export interface Route {
    method: string;
    path: string;
    handler: any;
    shouldBeProtected: boolean;
}

export const createRoutes = (
    config: AppConfig,
    datasource: DataSource
): Routes => {
    const routes: Routes = {
        public: [],
        protected: [],
    };
    [
        ...createUserRoutes(datasource),
        ...createAuthRoutes(config.jwt, datasource),
        ...createProductRoutes(config, datasource),
    ].forEach((r: Route) => {
        if (r.shouldBeProtected) {
            routes.protected.push(r);
        } else {
            routes.public.push(r);
        }
    });
    return routes;
};

export const createRoute = (
    method: string,
    path: string,
    handler: any,
    shouldBeProtected: boolean = false
): Route => {
    return {
        method: method.toLowerCase(),
        path,
        shouldBeProtected,
        handler: async (req: Request, res: Response, next: NextFunction) => {
            if (!res.errors.length) {
                await handler(req, res);
            }
            next();
        },
    };
};
