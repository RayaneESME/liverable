import bcrypt from "bcrypt";
import { IsString, Length, MinLength } from "class-validator";
import {
    passwordMinLength,
    usernameMaxLength,
    usernameMinLength,
} from "@/app/validation/constraints";
import { IsIdenticalTo } from "../validation/validators";
import { User } from "./user.entity";
import {
    passwordHashSaltRounds,
    notIdenticalPasswordsErrorMsg,
} from "@/constants";

export class UserCreationDTO {
    @IsString()
    @Length(usernameMinLength, usernameMaxLength)
    username: string;

    @IsString()
    @MinLength(passwordMinLength)
    password: string;

    @IsIdenticalTo("password", {
        message: notIdenticalPasswordsErrorMsg,
    })
    passwordConfirmation: string;

    static toUser(dto: UserCreationDTO): User {
        return new User(
            dto.username,
            bcrypt.hashSync(dto.password, passwordHashSaltRounds)
        );
    }
}

export class UserQueryDTO {
    id: string;
    username: string;

    static fromUser(user: User): UserQueryDTO {
        if (user === null) return null;
        return {
            id: user.id,
            username: user.username,
        };
    }
}
