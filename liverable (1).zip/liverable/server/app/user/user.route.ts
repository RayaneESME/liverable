import { UserCreationDTO, UserQueryDTO } from "./user.dto";
import { User } from "./user.entity";
import { UserService } from "./user.service";
import { Route, createRoute } from "@/app/route";
import { httpGET, httpPOST } from "@/constants";
import { Request, Response } from "@/app/common";
import { DataSource } from "typeorm";
import { SetupService } from "../setup/setup.service";
import { Setup } from "../setup/setup.entity";

const basePath: string = "user";

export class UserController {
    constructor(
        private readonly userService: UserService,
        private readonly setupService: SetupService
    ) {
        this.create = this.create.bind(this);
        this.get = this.get.bind(this);
        this.getCurrentUser = this.getCurrentUser.bind(this);
    }

    async create(req: Request<UserCreationDTO>, res: Response): Promise<void> {
        const user = await this.userService.create(
            UserCreationDTO.toUser(req.body)
        );
        await this.setupService.setAdminCreated();

        res.data = UserQueryDTO.fromUser(user);
    }

    async get(req: Request, res: Response): Promise<void> {
        const user: User = await this.userService.getByID(req.params["id"]);
        res.data = UserQueryDTO.fromUser(user);
    }

    async getCurrentUser(req: Request, res: Response): Promise<void> {
        res.data = UserQueryDTO.fromUser(req.currentUser);
    }
}

export const createUserRoutes = (datasource: DataSource): Route[] => {
    const userController: UserController = new UserController(
        UserService.getInstance(datasource.getRepository(User)),
        SetupService.getInstance(datasource.getRepository(Setup))
    );

    return [
        createRoute(httpPOST, basePath, userController.create),
        createRoute(httpGET, `${basePath}/:id`, userController.get),
        createRoute(
            httpGET,
            `${basePath}/current`,
            userController.getCurrentUser,
            true
        ),
    ];
};
