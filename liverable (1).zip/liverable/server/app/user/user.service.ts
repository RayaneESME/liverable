import { Repository } from "typeorm";
import { User } from "./user.entity";

let instance: UserService = null;

export class UserService {
    private constructor(private readonly userRepo: Repository<User>) {}

    async create(user: User): Promise<User> {
        return await this.userRepo.save(user);
    }

    async getByID(id: string): Promise<User | null> {
        return await this.userRepo.findOne({ where: { id } });
    }

    async getByUsername(username: string): Promise<User | null> {
        return await this.userRepo.findOne({ where: { username } });
    }

    static getInstance(userRepo: Repository<User>): UserService {
        if (instance === null) {
            instance = new UserService(userRepo);
        }
        return instance;
    }
}
