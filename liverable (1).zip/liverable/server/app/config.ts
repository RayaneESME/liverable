import { JWTConfig } from "./auth/jwt.service";

export interface AppConfig {
    domain: string;
    port: string;
    jwt: JWTConfig;
}
