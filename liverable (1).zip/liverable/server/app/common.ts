import express from "express";
import { User } from "./user/user.entity";
import {
    NO_ADMIN_FOUND_TYPE,
    NO_ADMIN_FOUND_MESSAGE,
    INCORRECT_CREDENTIALS_TYPE,
    INCORRECT_CREDENTIALS_MESSAGE,
    UNAUTHORIZED_ACTION_TYPE,
    UNAUTHORIZED_ACTION_MESSAGE,
    ADMIN_FOUND_TYPE,
    ADMIN_FOUND_MESSAGE,
} from "@/constants";

export interface Error {
    type: string;
    message: string;
}

export interface Request<T = any> extends express.Request {
    body: T;
    currentUser?: User;
}

export interface Response extends express.Response {
    authorized?: boolean;
    data?: any;
    errors?: Error[];
}

export class ResponseDTO {
    data: any;
    errors: Error[];

    static fromResponse(res: Response): ResponseDTO {
        return {
            data: res.data || null,
            errors: res.errors || [],
        };
    }
}

export const noAdminFoundError: Error = {
    type: NO_ADMIN_FOUND_TYPE,
    message: NO_ADMIN_FOUND_MESSAGE,
};

export const incorrectCredentialsError: Error = {
    type: INCORRECT_CREDENTIALS_TYPE,
    message: INCORRECT_CREDENTIALS_MESSAGE,
};

export const unauthorizedActionError: Error = {
    type: UNAUTHORIZED_ACTION_TYPE,
    message: UNAUTHORIZED_ACTION_MESSAGE,
};

export const adminFoundError: Error = {
    type: ADMIN_FOUND_TYPE,
    message: ADMIN_FOUND_MESSAGE,
};
