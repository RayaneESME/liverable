export const usernameMinLength: number = 4;
export const usernameMaxLength: number = 12;
export const passwordMinLength: number = 12;
export const productNameMinLength: number = 4;
export const productNameMaxLength: number = 12;
export const productDescriptionMaxLength: number = 120;
