import {
    ValidationArguments,
    ValidationOptions,
    registerDecorator,
} from "class-validator";

export function IsIdenticalTo(
    targetPropertyName: string,
    validationOptions?: ValidationOptions
) {
    return function (object: Object, propertyName: string) {
        registerDecorator({
            name: "IsIdenticalTo",
            target: object.constructor,
            propertyName: propertyName,
            constraints: [targetPropertyName],
            options: validationOptions,
            validator: {
                validate(value: any, args: ValidationArguments) {
                    // @ts-ignore
                    const targetPropertyValue = args.object[targetPropertyName];
                    return value === targetPropertyValue;
                },
            },
        });
    };
}
