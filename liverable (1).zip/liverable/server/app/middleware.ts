import { json, NextFunction } from "express";
import { DataSource } from "typeorm";
import cors from "cors";
import { Request, Response, ResponseDTO } from "@/app/common";
import { createSetupMiddlewares } from "./setup/setup.middleware";
import { createAuthMiddleware } from "./auth/auth.middleware";
import { AppConfig } from "./config";
import { staticURLPrefix } from "@/constants";

export type Middleware = (
    req: Request,
    res: Response,
    next: NextFunction
) => void;

export interface Middlewares {
    before: Middleware[];
    guard: Middleware[];
    after: Middleware[];
}

export const createMiddlewares = (
    config: AppConfig,
    datasource: DataSource
): Middlewares => {
    return {
        before: [
            json({ limit: "50mb" }),
            cors({
                origin: "http://localhost:3000",
            }),
            startMiddleware,
            ...createSetupMiddlewares(datasource),
        ],
        guard: [createAuthMiddleware(config.jwt, datasource)],
        after: [endMiddleware],
    };
};

export const createMiddleware = (
    perform: (req: Request, res: Response) => void | Promise<void>,
    skipWhenError: boolean = true
): Middleware => {
    return async (req: Request, res: Response, next: NextFunction) => {
        if (!skipWhenError || !res.errors.length) {
            await perform(req, res);
        }
        next();
    };
};

const startMiddleware = createMiddleware((_: Request, res: Response) => {
    res.errors = [];
    res.authorized = true;
}, false);

const endMiddleware = createMiddleware((req: Request, res: Response) => {
    if (req.url.startsWith(staticURLPrefix)) {
        return;
    }

    if (res.errors.length) {
        res = res.status(400);
    } else if (!res.errors.length && !res.data) {
        res = res.status(404);
    } else {
        res = res.status(200);
    }
    res.json(ResponseDTO.fromResponse(res));
}, false);
