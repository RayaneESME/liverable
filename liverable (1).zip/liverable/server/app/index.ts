import express, { Express } from "express";
import { DataSource } from "typeorm";
import { AppConfig } from "./config";
import { Route, Routes, createRoutes } from "./route";
import { Middleware, Middlewares, createMiddlewares } from "./middleware";
import { staticDir, apiURLPrefix, staticURLPrefix } from "@/constants";

export const bootstrap = (config: AppConfig, datasource: DataSource) => {
    const routes: Routes = createRoutes(config, datasource);
    const middlewares: Middlewares = createMiddlewares(config, datasource);

    startApp(config, routes, middlewares, () => {
        console.log(`[server]: running on port ${config.port}`);
    });
};

const startApp = (
    config: AppConfig,
    routes: Routes,
    middlewares: Middlewares,
    onStart: () => void
) => {
    const app: Express = express();

    // static
    app.use(staticURLPrefix, express.static(staticDir));

    // API
    middlewares.before.forEach((m: Middleware) => {
        app.use(m);
    });
    routes.public.forEach((r: Route) => {
        // @ts-ignore
        app[r.method](`${apiURLPrefix}/${r.path}`, r.handler);
    });
    routes.protected.forEach((r: Route) => {
        // @ts-ignore
        app[r.method](
            `${apiURLPrefix}/${r.path}`,
            ...middlewares.guard,
            r.handler
        );
    });
    middlewares.after.forEach((m: Middleware) => {
        app.use(m);
    });

    app.listen(config.port, onStart);
};
