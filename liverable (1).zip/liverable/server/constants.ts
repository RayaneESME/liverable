import { join } from "path";

export const rootDir: string = process.cwd();
export const entitiesPath: string = join(rootDir, "/app/**/*.entity.ts");
export const migrationsPath: string = join(
    rootDir,
    "/database/migrations/*.ts"
);
export const staticDir: string = join(rootDir, "/public/static");
export const imagesDir: string = join(staticDir, "images");

export const httpGET = "GET";
export const httpPOST = "POST";
export const httpPUT = "PUT";
export const httpDELETE = "DELETE";

export const setupEntityID = "setupEntityID";

export const NO_ADMIN_FOUND_TYPE = "NO_ADMIN_FOUND";
export const NO_ADMIN_FOUND_MESSAGE = "no admin found message";
export const ADMIN_FOUND_TYPE = "ADMIN_FOUND";
export const ADMIN_FOUND_MESSAGE = "admin found message";
export const INCORRECT_CREDENTIALS_TYPE = "INCORRECT_CREDENTIALS_TYPE";
export const INCORRECT_CREDENTIALS_MESSAGE = "incorrect username or password";
export const UNAUTHORIZED_ACTION_TYPE = "UNAUTHORIZED_ACTION_TYPE";
export const UNAUTHORIZED_ACTION_MESSAGE = "unauthorized action";

export const passwordHashSaltRounds: number = 12;

export const notIdenticalPasswordsErrorMsg: string =
    "the values provided for `password` and `confirmation password` are different";

export const apiURLPrefix: string = "/api/v1";
export const staticURLPrefix: string = "/static";
