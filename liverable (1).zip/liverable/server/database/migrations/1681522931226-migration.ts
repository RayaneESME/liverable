import { MigrationInterface, QueryRunner } from "typeorm";

export class Migration1681522931226 implements MigrationInterface {
    name = 'Migration1681522931226'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "setup" ("id" varchar PRIMARY KEY NOT NULL DEFAULT ('setupEntityID'), "isAdminCreated" boolean NOT NULL)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "setup"`);
    }

}
