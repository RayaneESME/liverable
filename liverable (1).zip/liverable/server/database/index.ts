import { DataSource } from "typeorm";
import { entitiesPath, migrationsPath } from "@/constants";
import { DatabaseConfig } from "./config";

export const getDatasource = (config: DatabaseConfig): DataSource => {
    return new DataSource({
        // @ts-ignore
        type: config.type,
        database: config.url,
        entities: [entitiesPath],
        migrations: [migrationsPath],
    });
};
