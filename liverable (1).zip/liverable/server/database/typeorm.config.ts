import dotenv from "dotenv";
import { getDatasource } from ".";

dotenv.config();

export default getDatasource({
    type: process.env.DATABASE_TYPE,
    url: process.env.DATABASE_URL,
});
