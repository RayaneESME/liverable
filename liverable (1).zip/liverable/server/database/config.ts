export interface DatabaseConfig {
    type: string;
    url: string;
}
