import dotenv from "dotenv";
import { AppConfig } from "@/app/config";
import { DatabaseConfig } from "@/database/config";

export interface Config {
    app: AppConfig;
    database: DatabaseConfig;
}

export const loadConfig = (): Config => {
    dotenv.config();

    return {
        app: {
            domain: process.env.APP_DOMAIN,
            port: process.env.APP_PORT,
            jwt: {
                secret: process.env.JWT_SECRET,
                expiresIn: process.env.JWT_EXPIRES_IN,
            },
        },
        database: {
            type: process.env.DATABASE_TYPE,
            url: process.env.DATABASE_URL,
        },
    } as Config;
};
