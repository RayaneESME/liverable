import { DataSource } from "typeorm";
import { loadConfig, Config } from "@/config";
import { bootstrap } from "@/app";
import { getDatasource } from "@/database";

const config: Config = loadConfig();

const datasource: DataSource = getDatasource(config.database);
datasource
    .initialize()
    .then(() => {
        bootstrap(config.app, datasource);
    })
    .catch((err) => {
        console.error(`failed to initialize datasource: ${err}`);
    });
