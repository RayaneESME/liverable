"use client";

import { ProductCreationDTO } from "@/api/product/dto";
import Container from "@/app/container/Container";
import { PageRedirectWrapper } from "@/app/container/PageRedirectWrapper";
import { useForm } from "@/state/hooks/useForm";
import { AppDispatch, AppState } from "@/state/store";
import { createProduct } from "@/state/store/actions";
import {
    Box,
    Button,
    Card,
    CardBody,
    Flex,
    FormControl,
    FormErrorMessage,
    FormLabel,
    HStack,
    Image,
    Input,
    Textarea,
    VStack,
} from "@chakra-ui/react";
import { FormikHelpers, FormikValues } from "formik";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";
import { ChangeEvent, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

const CreateProduct = () => {
    const router: AppRouterInstance = useRouter();
    const isAuthenticated: boolean = useSelector(
        (state: AppState) => state.rootReducer.isAuthenticated
    );

    useEffect(() => {
        if (!isAuthenticated) {
            router.push("/");
        }
    }, []);

    const dispatch: AppDispatch = useDispatch();
    const [imagePreview, setImagePreview] = useState("");
    const [image, setImage] = useState(null);

    const handleImageSelection = (e: ChangeEvent<HTMLInputElement>) => {
        setImagePreview(URL.createObjectURL(e.target.files[0]));
        setImage(e.target.files[0]);
    };

    const { fields, isSubmitting, handleChange, handleBlur, handleSubmit } =
        useForm(ProductCreationDTO, {
            initialValues: initialValues,
            onSubmit: (
                values: FormikValues,
                _: FormikHelpers<FormikValues>
            ) => {
                const dto: ProductCreationDTO =
                    ProductCreationDTO.fromFormikValues(values);

                if (image !== null) {
                    const reader = new FileReader();
                    reader.readAsDataURL(image);
                    reader.onload = () => {
                        const result: string = reader.result.toString();
                        const headerSuffix: string = "base64,";

                        dto.b64Image = result.substring(
                            result.indexOf(headerSuffix) + headerSuffix.length
                        );

                        dispatch(createProduct(dto)).then(() =>
                            router.push("/store")
                        );
                    };
                } else {
                    dispatch(createProduct(dto)).then(() =>
                        router.push("/store")
                    );
                }
            },
        });

    return (
        <PageRedirectWrapper>
            <Box h={"calc(100vh - 120px)"}>
                <Container>
                    <Flex align={"center"} justify={"center"}>
                        <Card>
                            <CardBody>
                                <form onSubmit={handleSubmit}>
                                    <VStack spacing="5" w="550px">
                                        <FormControl
                                            isInvalid={fields.name.isInvalid}
                                        >
                                            <FormLabel>Name</FormLabel>
                                            <Input
                                                type="text"
                                                name="name"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                value={fields.name.value}
                                            />
                                            {fields.name.errors.map(
                                                (error: any, idx: number) => {
                                                    return (
                                                        <FormErrorMessage
                                                            key={idx}
                                                        >
                                                            {error}
                                                        </FormErrorMessage>
                                                    );
                                                }
                                            )}
                                        </FormControl>

                                        <FormControl>
                                            <HStack
                                                w="100%"
                                                justify={"space-between"}
                                                align={"center"}
                                            >
                                                <Image
                                                    maxW={"300px"}
                                                    maxH={"200px"}
                                                    src={imagePreview}
                                                    fallbackSrc="/static/images/300x200_fallback.png"
                                                />

                                                <Button type="button">
                                                    <FormLabel
                                                        w="100%"
                                                        h="100%"
                                                        p="0"
                                                        m="0"
                                                        display={"flex"}
                                                        alignItems={"center"}
                                                        justifyContent={
                                                            "center"
                                                        }
                                                        htmlFor="product-image"
                                                        cursor={"pointer"}
                                                    >
                                                        Select Image
                                                    </FormLabel>
                                                </Button>
                                                <Input
                                                    id="product-image"
                                                    visibility={"hidden"}
                                                    position={"absolute"}
                                                    type="file"
                                                    onChange={
                                                        handleImageSelection
                                                    }
                                                />
                                            </HStack>
                                        </FormControl>

                                        <FormControl
                                            isInvalid={fields.price.isInvalid}
                                        >
                                            <FormLabel>Price</FormLabel>
                                            <HStack>
                                                <Input
                                                    type="text"
                                                    name="price"
                                                    onChange={handleChange}
                                                    onBlur={handleBlur}
                                                    value={fields.price.value}
                                                />
                                                <Box as="span">€</Box>
                                            </HStack>
                                            {fields.price.errors.map(
                                                (error: any, idx: number) => {
                                                    return (
                                                        <FormErrorMessage
                                                            key={idx}
                                                        >
                                                            {error}
                                                        </FormErrorMessage>
                                                    );
                                                }
                                            )}
                                        </FormControl>

                                        <FormControl
                                            isInvalid={
                                                fields.description.isInvalid
                                            }
                                        >
                                            <FormLabel>Description</FormLabel>
                                            <Textarea
                                                name="description"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                value={fields.description.value}
                                            />
                                            {fields.description.errors.map(
                                                (error: any, idx: number) => {
                                                    return (
                                                        <FormErrorMessage
                                                            key={idx}
                                                        >
                                                            {error}
                                                        </FormErrorMessage>
                                                    );
                                                }
                                            )}
                                        </FormControl>

                                        <Button
                                            mt={4}
                                            colorScheme={"purple"}
                                            isLoading={isSubmitting}
                                            type="submit"
                                        >
                                            Create Product
                                        </Button>
                                    </VStack>
                                </form>
                            </CardBody>
                        </Card>
                    </Flex>
                </Container>
            </Box>
        </PageRedirectWrapper>
    );
};

export default CreateProduct;

const initialValues = {
    name: "",
    description: "",
    price: "",
};
