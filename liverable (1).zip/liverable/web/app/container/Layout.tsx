import { ReactNode, useEffect } from "react";
import Footer from "../components/Footer";
import Header from "../components/Header";
import {
    Box,
    Divider,
    Flex,
    Spinner,
    VStack,
    useToast,
} from "@chakra-ui/react";
import { AppDispatch, AppState } from "@/state/store";
import { useDispatch, useSelector } from "react-redux";
import { getCurrentUser, untriggerToast } from "@/state/store/actions";
import { Modal } from "../components/Modal";

interface Props {
    children: ReactNode;
}

const Layout = ({ children }: Props) => {
    const dispatch: AppDispatch = useDispatch();
    const toast = useToast();
    const toastOptions = useSelector(
        (state: AppState) => state.rootReducer.toast
    );
    const isLoading = useSelector(
        (state: AppState) => state.rootReducer.isLoading
    );

    useEffect(() => {
        dispatch(getCurrentUser());
    }, []);

    useEffect(() => {
        if (!toastOptions.triggered) return;

        toast(toastOptions);
        dispatch(untriggerToast());
    }, [toastOptions]);

    return (
        <>
            <VStack align={"start"} w="100vw" spacing={"0"}>
                <Box w="100%">
                    <Header />
                    <Divider />
                </Box>
                <Box w="100%">{children}</Box>
                <Box w="100%">
                    <Divider />
                    <Footer />
                </Box>

                {isLoading && (
                    <Modal>
                        <Flex align={"center"} justify={"center"} h="100vh">
                            <Spinner colorScheme={"purple"} />
                        </Flex>
                    </Modal>
                )}
            </VStack>
        </>
    );
};

export default Layout;
