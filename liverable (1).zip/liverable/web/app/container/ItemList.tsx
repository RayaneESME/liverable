import {
    Box,
    Button,
    Flex,
    HStack,
    Icon,
    VStack,
    Wrap,
    WrapItem,
} from "@chakra-ui/react";
import { TiPlus } from "react-icons/ti";
import { Message } from "../components/Message";

interface Props<T> {
    items: T[];
    onAddClick?: () => void;
    textWhenEmpty?: string;
    render: (item: T) => React.ReactNode;
}

export function ItemList<T>({
    items,
    render,
    onAddClick,
    textWhenEmpty,
}: Props<T>) {
    return (
        <VStack w="100%" justify={"start"} mt={"1rem"}>
            {onAddClick && (
                <Flex w="100%">
                    <Button ml="auto" onClick={onAddClick}>
                        <HStack>
                            <Box as="span">Add new product</Box>
                            <Icon as={TiPlus} fontSize={"1.5rem"} />
                        </HStack>
                    </Button>
                </Flex>
            )}
            <Wrap w="100%" spacing={6} p="1rem">
                {!items.length && (
                    <Message
                        message={textWhenEmpty ? textWhenEmpty : "No items"}
                    />
                )}

                {items.map((item: T) => {
                    if (!item) {
                        return null;
                    }
                    // @ts-ignore
                    return <WrapItem key={item.id}>{render(item)}</WrapItem>;
                })}
            </Wrap>
        </VStack>
    );
}
