import { AppState } from "@/state/store";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";

interface Props {
    children: React.ReactNode;
}

export const PageRedirectWrapper = ({ children }: Props) => {
    const router: AppRouterInstance = useRouter();
    const isSetupReady: boolean = useSelector(
        (state: AppState) => state.rootReducer.isSetupReady
    );
    if (!isSetupReady) {
        router.push("/signup");
    }
    return <>{children}</>;
};
