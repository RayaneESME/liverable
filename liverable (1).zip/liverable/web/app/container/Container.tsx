import { ReactNode } from "react";
import { Flex } from "@chakra-ui/react";

interface Props {
    children: ReactNode;
}

const Container = ({ children }: Props) => {
    return (
        <Flex maxW={"1200px"} h={"100%"} mx={"auto"} justify="center">
            {children}
        </Flex>
    );
};

export default Container;
