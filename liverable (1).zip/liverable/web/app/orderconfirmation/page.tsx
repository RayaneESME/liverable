"use client";

import Container from "../container/Container";
import { Message } from "../components/Message";
import { Box } from "@chakra-ui/react";

const OrderConfirmation = () => {
    return (
        <Box minH={"calc(100vh - 120px)"}>
            <Container>
                <Message
                    message={
                        " Thank you for your order. We will be in touch with you shortly for the delivery"
                    }
                />
            </Container>
        </Box>
    );
};

export default OrderConfirmation;
