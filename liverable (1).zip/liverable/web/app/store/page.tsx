"use client";

import { PageRedirectWrapper } from "../container/PageRedirectWrapper";
import { AppDispatch, AppState } from "@/state/store";
import { useDispatch, useSelector } from "react-redux";
import { ProductQueryDTO } from "@/api/product/dto";
import React from "react";
import { getAllProducts } from "@/state/store/actions";
import { ItemList } from "../container/ItemList";
import { Product } from "../components/Product";
import Container from "../container/Container";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";
import { Box } from "@chakra-ui/react";

const Store = () => {
    const router: AppRouterInstance = useRouter();
    const dispatch: AppDispatch = useDispatch();
    const isAuthenticated: boolean = useSelector(
        (state: AppState) => state.rootReducer.isAuthenticated
    );
    const products: ProductQueryDTO[] = useSelector(
        (state: AppState) => state.rootReducer.products
    );

    React.useEffect(() => {
        dispatch(getAllProducts());
    }, [dispatch]);

    return (
        <PageRedirectWrapper>
            <Box w={"100%"} minH={"calc(100vh - 120px)"}>
                <Container>
                    {products && (
                        <ItemList<ProductQueryDTO>
                            items={products}
                            textWhenEmpty={"No product in the store"}
                            render={(item: ProductQueryDTO) => (
                                <Product item={item} />
                            )}
                            onAddClick={
                                isAuthenticated
                                    ? () => router.push("/product/create")
                                    : null
                            }
                        />
                    )}
                </Container>
            </Box>
        </PageRedirectWrapper>
    );
};
export default Store;
