"use client";

import "./globals.css";
import Layout from "./container/Layout";
import { ChakraProvider, extendTheme } from "@chakra-ui/react";
import { Provider } from "react-redux";
import { store } from "@/state/store";

const theme = extendTheme({
    fonts: {
        body: `'Roboto', sans-serif`,
    },
});

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en">
            <title>My E-commerce Store</title>
            <body>
                <Provider store={store}>
                    <ChakraProvider theme={theme}>
                        <Layout>{children}</Layout>
                    </ChakraProvider>
                </Provider>
            </body>
        </html>
    );
}
