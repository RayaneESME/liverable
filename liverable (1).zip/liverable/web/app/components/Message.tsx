import { Flex, Text } from "@chakra-ui/react";

interface Props {
    message: string;
}

export const Message = ({ message }: Props) => {
    return (
        <Flex
            w="100%"
            height="3rem"
            mt="1rem"
            p={4}
            bg="purple"
            color="white"
            borderRadius=".5rem"
            alignItems={"center"}
        >
            <Text as="b">{message}</Text>
        </Flex>
    );
};
