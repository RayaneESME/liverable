import styles from "./Cart.module.css";
import { Box, HStack, Icon, Text } from "@chakra-ui/react";
import { CgShoppingCart } from "react-icons/cg";
import { useSelector } from "react-redux";
import { AppState } from "@/state/store";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";

export const Cart = () => {
    const router: AppRouterInstance = useRouter();
    const cart = useSelector((state: AppState) => state.rootReducer.cart);

    return (
        <HStack className={styles.cart}>
            <Text as="b" color={"black"}>
                Cart
            </Text>
            <Box
                as="button"
                className={styles.cart__content}
                color="purple"
                onClick={() => router.push("/checkout")}
            >
                <Box className={styles.cart__totalCount}>{cart.totalCount}</Box>
                <Icon className={styles.cart__icon} as={CgShoppingCart} />
            </Box>
        </HStack>
    );
};
