import { ProductQueryDTO } from "@/api/product/dto";
import { AppDispatch } from "@/state/store";
import { deleteProductFromCart } from "@/state/store/actions";
import { Box, Button, Flex, HStack, Icon, Text } from "@chakra-ui/react";
import { useDispatch } from "react-redux";
import { HiMinus } from "react-icons/hi";

interface Props {
    item: ProductQueryDTO;
    count: number;
}

export const CheckoutItem = ({ item, count }: Props) => {
    const dispatch: AppDispatch = useDispatch();

    const handleDeleteProductClick = () => {
        dispatch(deleteProductFromCart(item));
    };

    return (
        <Flex
            width="full"
            justify="space-between"
            align="center"
            display={{ base: "none", md: "flex" }}
        >
            <HStack flex={"1"} justifyContent={"space-between"}>
                <Box as="span">{item.name}</Box>
                <Box as="span" fontWeight="bold">
                    x
                </Box>
                <Box as="span">{count}</Box>
                <Button
                    onClick={handleDeleteProductClick}
                    colorScheme={"red"}
                    p="1em"
                    w="1rem"
                    h="1rem"
                >
                    <Icon as={HiMinus} />
                </Button>
            </HStack>
            <Text as="span" fontWeight="medium" ml={"10em"}>
                €{item.price}
            </Text>
        </Flex>
    );
};
