import styles from "./Product.module.css";
import { ProductQueryDTO } from "@/api/product/dto";
import { upperFirstLetter } from "@/common";
import { AppDispatch, AppState } from "@/state/store";
import { addProductToCart, deleteProduct } from "@/state/store/actions";
import {
    Box,
    Button,
    Card,
    CardBody,
    CardFooter,
    CardHeader,
    HStack,
    Heading,
    Icon,
    Image,
    Text,
    VStack,
} from "@chakra-ui/react";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";

import { BsCartPlusFill } from "react-icons/bs";
import { FaRegEdit } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";

interface Props {
    item: ProductQueryDTO;
}

export const Product = ({ item }: Props) => {
    const router: AppRouterInstance = useRouter();
    const dispatch: AppDispatch = useDispatch();
    const isAuthenticated: boolean = useSelector(
        (state: AppState) => state.rootReducer.isAuthenticated
    );

    const handleDeleteClick = () => {
        dispatch(deleteProduct(item.id));
    };

    const handleUpdateClick = () => {
        router.push(`/product/update/${item.id}`);
    };

    const handleAddToCartClick = () => {
        dispatch(addProductToCart(item));
    };

    return (
        <HStack alignItems={"start"}>
            <Card className={styles.product} overflow={"hidden"}>
                <CardHeader p="0">
                    <Image
                        w={"300px"}
                        h={"200px"}
                        src={item.imageURL}
                        fallbackSrc={"/static/images/300x200_fallback.png"}
                    />
                </CardHeader>
                <CardBody p="0.5rem">
                    <VStack align={"start"}>
                        <HStack w="100%" justify={"space-between"}>
                            <Heading size={"xs"}>
                                {upperFirstLetter(item.name)}
                            </Heading>
                            <Text fontSize={"xl"} fontWeight={"bold"}>
                                €{item.price}
                            </Text>
                        </HStack>
                        <Text color={"gray.500"} fontSize={"0.9rem"}>
                            {upperFirstLetter(
                                item.description.substring(0, 60)
                            )}
                        </Text>
                    </VStack>
                </CardBody>
                <CardFooter p="0.6rem">
                    <Button p="1em" ml="auto" h="1.1rem" colorScheme="purple">
                        <HStack align={"center"} justify={"center"}>
                            <Box
                                as="span"
                                fontSize={"0.85rem"}
                                onClick={handleAddToCartClick}
                            >
                                Add to cart
                            </Box>
                            <Icon as={BsCartPlusFill} fontSize={"1.4rem"} />
                        </HStack>
                    </Button>
                </CardFooter>
            </Card>
            {isAuthenticated && (
                <VStack>
                    <Button
                        colorScheme={"yellow"}
                        p="1em"
                        w="1rem"
                        h="1rem"
                        onClick={handleUpdateClick}
                    >
                        <Icon as={FaRegEdit} />
                    </Button>
                    <Button
                        colorScheme={"red"}
                        p="1em"
                        w="1rem"
                        h="1rem"
                        onClick={handleDeleteClick}
                    >
                        <Icon as={MdDelete} />
                    </Button>
                </VStack>
            )}
        </HStack>
    );
};
