import { Box, Flex, Text } from "@chakra-ui/react";
import Container from "../container/Container";

const Footer = () => {
    return (
        <Box w={"100%"} bg={"white"}>
            <Container>
                <Flex w={"100%"} h={"60px"} alignItems={"center"}>
                    <Text fontSize={"sm"} color={"black"}>
                        &copy; {new Date().getFullYear()} rights reserved.
                    </Text>
                </Flex>
            </Container>
        </Box>
    );
};

export default Footer;
