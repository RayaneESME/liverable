import {
    Box,
    Button,
    ButtonGroup,
    HStack,
    Icon,
    Menu,
    MenuButton,
    MenuItem,
    MenuList,
    Spacer,
} from "@chakra-ui/react";
import { BiUserCircle } from "react-icons/bi";
import Container from "../container/Container";
import { useRouter } from "next/navigation";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, AppState } from "@/state/store";
import { UserQueryDTO } from "@/api/user/dto";
import { disconnect } from "@/state/store/actions";
import { Cart } from "./Cart";

const Header = () => {
    const router: AppRouterInstance = useRouter();
    const dispatch: AppDispatch = useDispatch();
    const isAuthenticated: boolean = useSelector(
        (state: AppState) => state.rootReducer.isAuthenticated
    );
    const currentUser: UserQueryDTO = useSelector(
        (state: AppState) => state.rootReducer.currentUser
    );

    const handleDisconnectClick = () => {
        dispatch(disconnect()).then(() => {
            router.push("/");
        });
    };

    return (
        <Box as="header" w="100%" h="60px" py="1em" bg="white.100">
            <Container>
                <HStack flex={"1"} align={"center"}>
                    <ButtonGroup color={"black"}>
                        <Button
                            bg={"transparent"}
                            onClick={() => router.push("/")}
                        >
                            Home
                        </Button>
                        <Button
                            bg={"transparent"}
                            onClick={() => router.push("/store")}
                        >
                            Store
                        </Button>
                    </ButtonGroup>
                    <Spacer />
                    <HStack>
                        <Box mr="4rem">
                            <Cart />
                        </Box>
                        <Spacer />
                        {!isAuthenticated && (
                            <Button
                                colorScheme={"yellow"}
                                onClick={() => router.push("/signin")}
                            >
                                Sign In
                            </Button>
                        )}
                        {isAuthenticated && (
                            <Menu>
                                <MenuButton>
                                    <HStack align={"center"}>
                                        <Box
                                            as="span"
                                            fontWeight={"bold"}
                                            color={"black"}
                                        >
                                            {currentUser.username}
                                        </Box>
                                        <Icon
                                            as={BiUserCircle}
                                            color={"purple"}
                                            fontSize={"1.7rem"}
                                        />
                                    </HStack>
                                </MenuButton>
                                <MenuList>
                                    <MenuItem
                                        as={Button}
                                        colorScheme={"purple"}
                                        onClick={handleDisconnectClick}
                                    >
                                        Disconnect
                                    </MenuItem>
                                </MenuList>
                            </Menu>
                        )}
                    </HStack>
                </HStack>
            </Container>
        </Box>
    );
};

export default Header;
