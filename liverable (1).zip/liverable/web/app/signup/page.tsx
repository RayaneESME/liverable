"use client";

import { useForm } from "@/state/hooks/useForm";
import { AppDispatch, AppState } from "@/state/store";
import { createUser, signin } from "@/state/store/actions";
import {
    Box,
    Button,
    Card,
    CardBody,
    Flex,
    FormControl,
    FormErrorMessage,
    FormLabel,
    Input,
    VStack,
} from "@chakra-ui/react";
import { FormikHelpers, FormikValues } from "formik";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { UserCreationDTO } from "@/api/user/dto";
import Container from "../container/Container";

const SignUp = () => {
    const router: AppRouterInstance = useRouter();

    const isAuthenticated: boolean = useSelector(
        (state: AppState) => state.rootReducer.isAuthenticated
    );
    if (isAuthenticated) {
        router.push("/");
    }

    const dispatch: AppDispatch = useDispatch();

    const { fields, isSubmitting, handleChange, handleBlur, handleSubmit } =
        useForm(UserCreationDTO, {
            initialValues: initialValues,
            onSubmit: (
                values: FormikValues,
                _: FormikHelpers<FormikValues>
            ) => {
                const dto: UserCreationDTO =
                    UserCreationDTO.fromFormikValues(values);

                dispatch(createUser(dto)).then(() => {
                    router.push("/signin");
                });
            },
        });

    return (
        <Box h={"calc(100vh - 120px)"}>
            <Container>
                <Flex align={"center"} justify={"center"}>
                    <Card>
                        <CardBody>
                            <form onSubmit={handleSubmit}>
                                <VStack spacing="5" w="450px">
                                    <FormControl
                                        isInvalid={fields.username.isInvalid}
                                    >
                                        <FormLabel>Username</FormLabel>
                                        <Input
                                            type="text"
                                            name="username"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={fields.username.value}
                                        />
                                        {fields.username.errors.map(
                                            (error: any, idx: number) => {
                                                return (
                                                    <FormErrorMessage key={idx}>
                                                        {error}
                                                    </FormErrorMessage>
                                                );
                                            }
                                        )}
                                    </FormControl>

                                    <FormControl
                                        isInvalid={fields.password.isInvalid}
                                    >
                                        <FormLabel>Password</FormLabel>
                                        <Input
                                            type="password"
                                            name="password"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={fields.password.value}
                                        />
                                        {fields.password.errors.map(
                                            (error: any, idx: number) => {
                                                return (
                                                    <FormErrorMessage key={idx}>
                                                        {error}
                                                    </FormErrorMessage>
                                                );
                                            }
                                        )}
                                    </FormControl>

                                    <FormControl
                                        isInvalid={
                                            fields.passwordConfirmation
                                                .isInvalid
                                        }
                                    >
                                        <FormLabel>
                                            Password Confirmation
                                        </FormLabel>
                                        <Input
                                            type="password"
                                            name="passwordConfirmation"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={
                                                fields.passwordConfirmation
                                                    .value
                                            }
                                        />
                                        {fields.passwordConfirmation.errors.map(
                                            (error: any, idx: number) => {
                                                return (
                                                    <FormErrorMessage key={idx}>
                                                        {error}
                                                    </FormErrorMessage>
                                                );
                                            }
                                        )}
                                    </FormControl>

                                    <Button
                                        colorScheme={"yellow"}
                                        isLoading={isSubmitting}
                                        type="submit"
                                    >
                                        Sign Up
                                    </Button>
                                </VStack>
                            </form>
                        </CardBody>
                    </Card>
                </Flex>
            </Container>
        </Box>
    );
};

export default SignUp;

const initialValues = {
    username: "",
    password: "",
    passwordConfirmation: "",
};
