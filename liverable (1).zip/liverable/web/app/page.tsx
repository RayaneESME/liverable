"use client";

import { Box, Button, Flex, Text, VStack } from "@chakra-ui/react";
import { PageRedirectWrapper } from "./container/PageRedirectWrapper";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";

const Home = () => {
    const router: AppRouterInstance = useRouter();

    return (
        <PageRedirectWrapper>
            <Flex
                w={"100%"}
                minH={"calc(100vh - 120px)"}
                align={"center"}
                justify={"center"}
            >
                <VStack>
                    <Text fontSize={"8xl"} color={"black"}>
                        Welcome To{" "}
                        <Box as="span" color={"purple"}>
                            My Store
                        </Box>
                    </Text>
                    <Button
                        colorScheme={"yellow"}
                        onClick={() => router.push("/store")}
                    >
                        Let&apos;s Go
                    </Button>
                </VStack>
            </Flex>
        </PageRedirectWrapper>
    );
};
export default Home;
