"use client";

import { AppDispatch, AppState } from "@/state/store";
import {
    Box,
    Button,
    Card,
    CardBody,
    CardFooter,
    Divider,
    Heading,
    Spacer,
    Stack,
    VStack,
} from "@chakra-ui/react";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { CheckoutItem } from "../components/CheckoutItem";
import { resetCart } from "@/state/store/actions";
import Container from "../container/Container";

const Checkout = () => {
    const dispatch: AppDispatch = useDispatch();
    const router: AppRouterInstance = useRouter();
    const cart = useSelector((state: AppState) => state.rootReducer.cart);

    const handleConfirmOrderClick = () => {
        router.push("orderconfirmation");
        dispatch(resetCart());
    };

    return (
        <Box w="100%" mx="auto" minH={"calc(100vh - 120px)"}>
            <Container>
                <VStack mt="2rem">
                    <Stack minW={"600px"}>
                        <Heading
                            fontSize="2xl"
                            fontWeight="extrabold"
                            color={"black"}
                        >
                            Shopping Cart (
                            <Box as="span" color={"purple"}>
                                {cart.totalCount}
                            </Box>{" "}
                            item(s))
                        </Heading>

                        {cart.totalCount && (
                            <Card>
                                <CardBody>
                                    <Stack spacing="6">
                                        {Object.keys(cart.products).map(
                                            (productID: string) => {
                                                const product =
                                                    cart.products[productID];
                                                return (
                                                    <CheckoutItem
                                                        key={productID}
                                                        item={product.item}
                                                        count={product.count}
                                                    />
                                                );
                                            }
                                        )}
                                    </Stack>
                                </CardBody>
                                <Divider />
                                <CardFooter>
                                    <Box as="span">Total</Box>
                                    <Spacer />
                                    <Box>€{cart.totalPrice}</Box>
                                </CardFooter>
                            </Card>
                        )}

                        {cart.totalCount && (
                            <Button
                                colorScheme={"purple"}
                                onClick={handleConfirmOrderClick}
                            >
                                Confirm Order
                            </Button>
                        )}
                    </Stack>
                </VStack>
            </Container>
        </Box>
    );
};

export default Checkout;
