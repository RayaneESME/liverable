import { UserCreationDTO, UserQueryDTO } from "@/api/user/dto";
import { AppDispatch, AppGetState, AppState } from ".";
import api from "@/api";
import {
    ADD_PRODUCT,
    ADD_TO_CART,
    DELETE_FROM_CART,
    DELETE_PRODUCT,
    DISPLAY_SUCCESS_TOAST,
    RESET_CART,
    SET_CURRENT_USER,
    SET_IS_LOADING,
    SET_IS_SETUP_READY,
    SET_PRODUCTS,
    UNTRIGGER_TOAST,
    UPDATE_PRODUCT,
} from "./types";
import { APICallErrors, APICallError } from "@/api/helper";
import { SignInDTO, SignInResponseDTO } from "@/api/auth/dto";
import {
    NO_ADMIN_FOUND_TYPE,
    destroyStoredAccessToken,
    setStoredAccessToken,
} from "@/common";
import {
    ProductCreationDTO,
    ProductQueryDTO,
    ProductUpdateDTO,
} from "@/api/product/dto";

export const signin = (dto: SignInDTO) => {
    return wrapAsyncAction(async (dispatch: AppDispatch, _: AppGetState) => {
        const { token }: SignInResponseDTO = await api.signin(dto);
        setStoredAccessToken(token);

        const currentUser: UserQueryDTO = await api.getCurrentUser();
        dispatch({
            type: SET_CURRENT_USER,
            payload: currentUser,
        });
    }, true);
};

export const disconnect = () => {
    return wrapAsyncAction(async (dispatch: AppDispatch, _: any) => {
        destroyStoredAccessToken();

        dispatch({
            type: SET_CURRENT_USER,
            payload: null,
        });
    });
};

export const getCurrentUser = () => {
    return wrapAsyncAction(
        async (dispatch: AppDispatch, getState: AppGetState) => {
            const state: AppState = getState();
            if (state.rootReducer.currentUser !== null) return;

            api.getCurrentUser()
                .then((currentUser: UserQueryDTO) => {
                    dispatch({
                        type: SET_CURRENT_USER,
                        payload: currentUser,
                    });
                })
                .catch(({ errors }: APICallErrors) => {
                    if (
                        errors.some(
                            (e: APICallError) => e.type === NO_ADMIN_FOUND_TYPE
                        )
                    ) {
                        dispatch({
                            type: SET_IS_SETUP_READY,
                            payload: false,
                        });
                    } else {
                        destroyStoredAccessToken();
                    }
                });
        }
    );
};

export const createUser = (dto: UserCreationDTO) => {
    return wrapAsyncAction(async (dispatch: AppDispatch, __: AppGetState) => {
        await api.createUser(dto).then(() => {
            dispatch({
                type: SET_IS_SETUP_READY,
                payload: true,
            });
        });
    }, true);
};

export const createProduct = (dto: ProductCreationDTO) => {
    return wrapAsyncAction(async (dispatch: AppDispatch, _: AppGetState) => {
        const product: ProductQueryDTO = await api.createProduct(dto);

        dispatch({
            type: ADD_PRODUCT,
            payload: product,
        });
    }, true);
};

export const updateProduct = (productID: string, dto: ProductUpdateDTO) => {
    return wrapAsyncAction(async (dispatch: AppDispatch, _: AppGetState) => {
        const product: ProductQueryDTO = await api.updateProduct(
            productID,
            dto
        );

        dispatch({
            type: UPDATE_PRODUCT,
            payload: product,
        });
    }, true);
};

export const getAllProducts = () => {
    return wrapAsyncAction(async (dispatch: AppDispatch, _: AppGetState) => {
        const products: ProductQueryDTO[] = await api.getAllProducts();

        dispatch({
            type: SET_PRODUCTS,
            payload: products,
        });
    });
};

export const deleteProduct = (productID: string) => {
    return wrapAsyncAction(async (dispatch: AppDispatch, _: AppGetState) => {
        await api.deleteProduct(productID);

        dispatch({
            type: DELETE_PRODUCT,
            payload: productID,
        });
    }, true);
};

export const addProductToCart = (product: ProductQueryDTO) => {
    return {
        type: ADD_TO_CART,
        payload: product,
    };
};

export const deleteProductFromCart = (product: ProductQueryDTO) => {
    return {
        type: DELETE_FROM_CART,
        payload: product,
    };
};

export const resetCart = () => {
    return {
        type: RESET_CART,
    };
};

export const untriggerToast = () => {
    return {
        type: UNTRIGGER_TOAST,
    };
};

export const setIsLoading = (isLoading: boolean) => {
    return {
        type: SET_IS_LOADING,
        paylod: isLoading,
    };
};

type performType = (
    dispatch: AppDispatch,
    getState: AppGetState
) => Promise<void>;

const wrapAsyncAction = (
    perform: performType,
    triggerToast: boolean = false
) => {
    return async (dispatch: AppDispatch, getState: AppGetState) => {
        dispatch(setIsLoading(true));

        await perform(dispatch, getState)
            .then(() => {
                if (!triggerToast) return;
                dispatch({
                    type: DISPLAY_SUCCESS_TOAST,
                    payload: {
                        title: "Success",
                        description: "Successful action",
                    },
                });
            })
            .catch((err: APICallErrors) => {
                if (!triggerToast) return;
                dispatch({
                    type: DISPLAY_SUCCESS_TOAST,
                    payload: {
                        title: "Failure",
                        description: `Failed action: ${err.errors.join("\n")}`,
                    },
                });
            });

        dispatch(setIsLoading(false));
    };
};
