import { AnyAction } from "@reduxjs/toolkit";
import {
    ADD_PRODUCT,
    ADD_TO_CART,
    DELETE_FROM_CART,
    DELETE_PRODUCT,
    DISPLAY_ERROR_TOAST,
    DISPLAY_SUCCESS_TOAST,
    RESET_CART,
    SET_CURRENT_USER,
    SET_IS_LOADING,
    SET_IS_SETUP_READY,
    SET_PRODUCTS,
    UNTRIGGER_TOAST,
    UPDATE_PRODUCT,
} from "./types";
import { ProductQueryDTO } from "@/api/product/dto";

const initialState = {
    isAuthenticated: false,
    isSetupReady: true,
    isLoading: false,
    currentUser: null,
    products: [],
    cart: {
        products: {},
        totalCount: 0,
        totalPrice: 0,
    },
    toast: {
        duration: 1000,
        isClosable: true,
        triggered: false,
    },
};

export const rootReducer = (state = initialState, action: AnyAction) => {
    switch (action.type) {
        case SET_IS_SETUP_READY: {
            return {
                ...state,
                isSetupReady: action.payload,
            };
        }
        case SET_CURRENT_USER: {
            return {
                ...state,
                currentUser: action.payload,
                isAuthenticated: action.payload !== null,
            };
        }
        case SET_PRODUCTS: {
            return {
                ...state,
                products: action.payload,
            };
        }
        case ADD_PRODUCT: {
            return {
                ...state,
                products: [...state.products, action.payload],
            };
        }
        case UPDATE_PRODUCT: {
            const newProducts: ProductQueryDTO[] = [...state.products];
            const idx: number = newProducts.findIndex(
                (p: ProductQueryDTO) => p.id === action.payload.id
            );
            newProducts[idx] = action.payload;

            return {
                ...state,
                products: newProducts,
            };
        }
        case DELETE_PRODUCT: {
            const newProducts: ProductQueryDTO[] = state.products.filter(
                (p: ProductQueryDTO) => p.id !== action.payload
            );
            return {
                ...state,
                products: newProducts,
            };
        }
        case DISPLAY_SUCCESS_TOAST: {
            return {
                ...state,
                toast: {
                    ...state.toast,
                    ...action.payload,
                    status: "success",
                    triggered: true,
                },
            };
        }
        case DISPLAY_ERROR_TOAST: {
            return {
                ...state,
                toast: {
                    ...state.toast,
                    ...action.payload,
                    status: "error",
                    triggered: true,
                },
            };
        }
        case UNTRIGGER_TOAST: {
            return {
                ...state,
                toast: {
                    ...state.toast,
                    triggered: false,
                },
            };
        }
        case ADD_TO_CART: {
            const cart = {
                products: { ...state.cart.products },
                totalCount: state.cart.totalCount,
                totalPrice: state.cart.totalPrice,
            };
            if (!cart.products[action.payload.id]) {
                cart.products[action.payload.id] = {
                    item: action.payload,
                    count: 0,
                    price: 0,
                };
            }
            cart.products[action.payload.id] = {
                ...cart.products[action.payload.id],
                count: cart.products[action.payload.id].count + 1,
                price:
                    cart.products[action.payload.id].price +
                    action.payload.price,
            };
            cart.totalCount += 1;
            cart.totalPrice += action.payload.price;
            return {
                ...state,
                cart: cart,
            };
        }
        case DELETE_FROM_CART: {
            const cart = {
                products: { ...state.cart.products },
                totalCount: state.cart.totalCount,
                totalPrice: state.cart.totalPrice,
            };
            if (!cart.products[action.payload.id]) {
                return state;
            }
            cart.products[action.payload.id] = {
                ...cart.products[action.payload.id],
                count: cart.products[action.payload.id].count - 1,
                price:
                    cart.products[action.payload.id].price -
                    action.payload.price,
            };
            cart.totalCount -= 1;
            cart.totalPrice -= action.payload.price;
            if (cart.products[action.payload.id].count === 0) {
                delete cart.products[action.payload.id];
            }
            return {
                ...state,
                cart: cart,
            };
        }
        case RESET_CART: {
            return {
                ...state,
                cart: { products: {}, totalCount: 0, totalPrice: 0 },
            };
        }
        case SET_IS_LOADING: {
            return {
                ...state,
                isLoading: action.payload,
            };
        }
    }
    return state;
};
