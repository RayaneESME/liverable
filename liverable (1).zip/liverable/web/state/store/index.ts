import { rootReducer } from "./reducers";
import { configureStore } from "@reduxjs/toolkit";

export const store = configureStore({ reducer: { rootReducer } });

export type AppState = ReturnType<typeof store.getState>;
export type AppGetState = typeof store.getState;
export type AppDispatch = typeof store.dispatch;
