import { FormikHelpers, FormikValues, useFormik } from "formik";

export interface useFormParams {
    initialValues: any;
    onSubmit: (values: FormikValues, _: FormikHelpers<FormikValues>) => void;
}

export interface useFormReturn {
    fields: useFormFields;
    isSubmitting: boolean;
    handleSubmit: (_: React.ChangeEvent<any>) => void;
    handleChange: (_: React.ChangeEvent<any>) => void;
    handleBlur: (_: React.ChangeEvent<any>) => void;
}

export interface useFormFields {
    [key: string]: useFormField;
}

export interface useFormField {
    value: string;
    isInvalid: boolean;
    errors: string[];
}

export function useForm(dtoType: any, params: useFormParams): useFormReturn {
    const {
        values,
        touched,
        errors,
        isSubmitting,
        handleChange,
        handleBlur,
        handleSubmit,
    } = useFormik({
        initialValues: params.initialValues,
        onSubmit: params.onSubmit,
        validate: (values: FormikValues) => {
            // @ts-ignore
            const dto = dtoType.fromFormikValues(values);
            // @ts-ignore
            return dto.validate();
        },
    });

    // @ts-ignore
    const fields: useFormFields = Object.keys(values).reduce(
        // @ts-ignore
        (previous, fieldName) => {
            return {
                ...previous,
                [fieldName]: {
                    // @ts-ignore
                    value: values[fieldName],
                    // @ts-ignore
                    isInvalid: (values[fieldName] &&
                        // @ts-ignore
                        touched[fieldName] &&
                        // @ts-ignore
                        errors[fieldName]) as boolean,
                    // @ts-ignore
                    errors: errors[fieldName] || [],
                },
            };
        },
        {} as useFormFields
    );

    return { fields, isSubmitting, handleChange, handleBlur, handleSubmit };
}
