import { postCall } from "../helper";
import { SignInDTO, SignInResponseDTO } from "./dto";

const basePath: string = "auth";

export default {
    signin(dto: SignInDTO): Promise<SignInResponseDTO> {
        return postCall<SignInResponseDTO>(`${basePath}/signin`, dto);
    },
};
