import { InputValidation } from "@/common";
import { FormikValues } from "formik";

export class SignInDTO extends InputValidation {
    username: string;
    password: string;

    constructor(username: string, password: string) {
        super();
        this.username = username;
        this.password = password;
    }

    static fromFormikValues(values: FormikValues): SignInDTO {
        return new SignInDTO(values.username, values.password);
    }
}

export interface SignInResponseDTO {
    token: string;
}
