import auth from "./auth";
import product from "./product";
import user from "./user";

export default {
    ...auth,
    ...user,
    ...product,
};
