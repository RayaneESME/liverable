import { InputValidation } from "@/common";
import {
    productDescriptionMaxLength,
    productNameMaxLength,
    productNameMinLength,
} from "@/validation/constraints";
import {
    IsNumberString,
    IsString,
    IsUrl,
    Length,
    MaxLength,
} from "class-validator";
import { FormikValues } from "formik";

export class ProductCreationDTO extends InputValidation {
    @IsString()
    @Length(productNameMinLength, productNameMaxLength)
    name: string;

    @IsString()
    @MaxLength(productDescriptionMaxLength)
    description: string;

    @IsNumberString()
    price: string;

    b64Image: string;

    constructor(name: string, description: string, price: string) {
        super();

        this.name = name;
        this.description = description;
        this.price = price;
    }

    static fromFormikValues(values: FormikValues): ProductCreationDTO {
        return new ProductCreationDTO(
            values.name,
            values.description,
            values.price
        );
    }
}

export class ProductUpdateDTO extends InputValidation {
    @IsString()
    @Length(productNameMinLength, productNameMaxLength)
    name: string;

    @IsString()
    @MaxLength(productDescriptionMaxLength)
    description: string;

    @IsNumberString()
    price: string;

    imageURL: string;

    b64Image: string;

    constructor(
        name: string,
        description: string,
        price: string,
        imageURL: string
    ) {
        super();

        this.name = name;
        this.description = description;
        this.price = price;
        this.imageURL = imageURL;
    }

    static fromFormikValues(values: FormikValues): ProductUpdateDTO {
        return new ProductUpdateDTO(
            values.name,
            values.description,
            values.price,
            values.imageURL
        );
    }
}

export class ProductQueryDTO {
    id: string;
    name: string;
    description: string;
    price: number;
    imageURL: string;
}
