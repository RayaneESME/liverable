import { deleteCall, getCall, postCall, putCall } from "../helper";
import { ProductCreationDTO, ProductQueryDTO, ProductUpdateDTO } from "./dto";

const basePath: string = "product";

export default {
    createProduct(dto: ProductCreationDTO): Promise<ProductQueryDTO> {
        return postCall<ProductQueryDTO>(basePath, dto);
    },

    updateProduct(
        productID: string,
        dto: ProductUpdateDTO
    ): Promise<ProductQueryDTO> {
        return putCall<ProductQueryDTO>(`${basePath}/${productID}`, dto);
    },

    getAllProducts(): Promise<ProductQueryDTO[]> {
        return getCall<ProductQueryDTO[]>(basePath);
    },

    deleteProduct(productID: string): Promise<void> {
        return deleteCall<void>(`${basePath}/${productID}`);
    },
};
