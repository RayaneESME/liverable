import { getCall, postCall } from "../helper";
import { UserCreationDTO, UserQueryDTO } from "./dto";

const basePath: string = "user";

export default {
    createUser(dto: UserCreationDTO): Promise<UserQueryDTO> {
        return postCall<UserQueryDTO>(basePath, dto);
    },

    getUser(userID: string): Promise<UserQueryDTO | null> {
        return getCall<UserQueryDTO | null>(`${basePath}/${userID}`);
    },

    getCurrentUser(): Promise<UserQueryDTO> {
        return getCall<UserQueryDTO>(`${basePath}/current`);
    },
};
