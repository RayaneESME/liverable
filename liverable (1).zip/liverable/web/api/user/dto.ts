import {
    passwordMinLength,
    usernameMaxLength,
    usernameMinLength,
} from "@/validation/constraints";
import { IsIdenticalTo } from "@/validation/validators";
import { IsString, Length, MinLength } from "class-validator";
import { FormikValues } from "formik";
import { InputValidation, notIdenticalPasswordsErrorMsg } from "@/common";

export class UserCreationDTO extends InputValidation {
    @IsString()
    @Length(usernameMinLength, usernameMaxLength)
    username: string;

    @IsString()
    @MinLength(passwordMinLength)
    password: string;

    @IsIdenticalTo("password", {
        message: notIdenticalPasswordsErrorMsg,
    })
    passwordConfirmation: string;

    constructor(
        username: string,
        password: string,
        passwordConfirmation: string
    ) {
        super();

        this.username = username;
        this.password = password;
        this.passwordConfirmation = passwordConfirmation;
    }

    static fromFormikValues(values: FormikValues): UserCreationDTO {
        return new UserCreationDTO(
            values.username,
            values.password,
            values.passwordConfirmation
        );
    }
}

export class UserQueryDTO {
    id: string;
    username: string;
}
