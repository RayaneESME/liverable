import { getStoredAccessToken } from "@/common";

const apiURL: string = "http://localhost:3001/api/v1";

export type APICallError = {
    type: string;
    message: string;
};

export class APICallErrors extends Error {
    errors: APICallError[];

    constructor(errors: APICallError[]) {
        super();

        this.errors = errors;
    }
}

type APICallResponse<T> = {
    data: T;
    errors: APICallError[];
};

export async function getCall<T>(path: string): Promise<T> {
    return apiCall("GET", path);
}

export async function postCall<T>(path: string, body: any): Promise<T> {
    return apiCall("POST", path, body);
}

export async function putCall<T>(path: string, body: any): Promise<T> {
    return apiCall("PUT", path, body);
}

export async function deleteCall<T>(path: string): Promise<T> {
    return apiCall("DELETE", path);
}

async function apiCall<T>(
    method: string,
    path: string,
    body?: any
): Promise<T> {
    const callOptions: {
        method: string;
        headers: HeadersInit;
        body?: BodyInit;
    } = {
        method: method,
        headers: getHeaders(),
    };
    if (body !== undefined) {
        callOptions.body = JSON.stringify(body);
    }

    let data: T = null;
    let errors: APICallError[] = [];
    try {
        const resp = await fetch(`${apiURL}/${path}`, callOptions);
        const json: APICallResponse<T> = await resp.json();
        data = json.data;
        errors = json.errors;
    } catch (err) {
        console.error(err);
        return;
    }

    if (errors.length) {
        throw new APICallErrors(errors);
    }
    return data;
}

function getHeaders(): HeadersInit {
    const accessToken: string | null = getStoredAccessToken();
    if (accessToken === null) {
        return {
            "content-type": "application/json;charset=UTF-8",
        };
    }
    return {
        "content-type": "application/json;charset=UTF-8",
        Authorization: `Bearer ${accessToken}`,
    };
}
