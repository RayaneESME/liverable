import { ValidationError, validateSync } from "class-validator";

const accessTokenLocalStoreKey: string = "APP_JWT_TOKEN_KEY";

export const getStoredAccessToken = (): string | null => {
    return localStorage.getItem(accessTokenLocalStoreKey);
};

export const setStoredAccessToken = (token: string) => {
    localStorage.setItem(accessTokenLocalStoreKey, token);
};

export const destroyStoredAccessToken = () => {
    localStorage.removeItem(accessTokenLocalStoreKey);
};

export class InputValidation {
    validate() {
        const errors: ValidationError[] = validateSync(this);
        return errors.reduce((previous, { property, constraints }) => {
            return {
                ...previous,
                // @ts-ignore
                [property]: Object.values(constraints),
            };
        }, {}) as InputValidationResult;
    }
}
export interface InputValidationResult {
    errors: object;
}

export const notIdenticalPasswordsErrorMsg: string =
    "the values provided for `password` and `confirmation password` are different";

export const NO_ADMIN_FOUND_TYPE = "NO_ADMIN_FOUND";
export const INCORRECT_CREDENTIALS_TYPE = "INCORRECT_CREDENTIALS_TYPE";
export const UNAUTHORIZED_ACTION_TYPE = "UNAUTHORIZED_ACTION_TYPE";

export const upperFirstLetter = (str: string): string => {
    return `${str.at(0).toUpperCase()}${str.substring(1).toLowerCase()}`;
};
